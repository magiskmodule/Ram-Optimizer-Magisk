# Changelog

Version 2.0:
1. Improved RAM management for better performance.
2. Reduced background usage and caches.
3. Enabled GMS Doze for power savings.
4. Integrated AdrenoBoost and Adreno Idler for GPU optimization.
5. Optimized MGLRU, Sched, and SimpleLMK.
6. Adjusted parameters for stability.
7. Updated system properties for aggressive RAM management.
8. Added new memory optimizations.
9. Tweaks for gaming and frame drops.
10. Adjusted file system cache and VM settings.
11. Aligned RAM management with main scripts.
12. Optimized main script for lower system usage.
13. Enhanced overall device memory.
14. Regular updates for improvement.

Fixed:
Screen Recording Working
Status Bar Bug Fixed 

Thanks @Bkworld03 And @Hourofdreams For Testing Module.

Version 1.0:
- Aggressive RAM Management
  - Optimized properties and scripts for multitasking.
  - Fine-tuned VM settings for enhanced responsiveness.
  - Tailored settings for improved gaming performance.
  - Reduced background cache for minimal interruptions.
  - Implemented techniques for smoother operation.
  - Fine-tuned cache clearance for better performance.
  - Adjusted settings for quicker data access.
  - Fine-tuned file system cache for improved responsiveness.
  - Enhanced low memory killer settings for optimal resource allocation.
  - Customized configurations based on device specifications.
  - Enabled low RAM mode for optimized daily performance.
  - Balanced RAM usage and smoother UI adjustments.
  - Gaming-specific tweaks for power and touch boost.
  - Aggressive background app management for enhanced efficiency.
  - File system cache adjustments for improved responsiveness.
  - VM tweaks for better RAM utilization.
  - Low memory killer settings to prevent unnecessary app terminations.

 Notes:
- Future updates may include additional optimizations and user-requested features.