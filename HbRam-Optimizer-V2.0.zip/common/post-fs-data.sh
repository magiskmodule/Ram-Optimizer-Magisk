#!/system/bin/sh

MODDIR=${0%/*}

# Function to write values to files
write() {
    [[ -f "$1" ]] && echo "$2" > "$1" 2>/dev/null
}

# Function to set device properties based on specifications
set_device_properties() {
    total_ram=$(free -m | awk '/^Mem:/{print $2}')
    storage_capacity=$(df -h /data | awk 'NR==2{print $2}')
    kernel_version=$(uname -r)

    case "$total_ram" in
        512) dirty_ratio_val=99 ;;
        1024) dirty_ratio_val=99 ;;
        2048) dirty_ratio_val=99 ;;
        4096) dirty_ratio_val=99 ;;
        *) dirty_ratio_val=99 ;;
    esac

    case "$storage_capacity" in
        "32G") dirty_background_bytes_val=8192 ;;
        *) dirty_background_bytes_val=8192 ;;
    esac

    case "$kernel_version" in
        4.*) extra_free_kbytes_val=16384 ;;
        *) extra_free_kbytes_val=16384 ;;
    esac

    write "/proc/sys/vm/dirty_ratio" "$dirty_ratio_val"
    write "/proc/sys/vm/dirty_background_bytes" "$dirty_background_bytes_val"
    write "/proc/sys/vm/extra_free_kbytes" "$extra_free_kbytes_val"

    if [ "$(echo "$android_version >= 9.0" | bc -l)" -eq 1 ]; then
        write "/proc/sys/vm/oom_kill_allocating_task" "1"
        write "/proc/sys/vm/dirty_ratio" "3"
    fi
}

# Function for RAM optimization
optimize_ram_aggressively() {
    # Aggressive RAM management settings
    echo 1 > /proc/sys/vm/drop_caches
    echo 99 > /proc/sys/vm/dirty_ratio
    echo 95 > /proc/sys/vm/dirty_background_ratio
    echo 0 > /proc/sys/vm/swappiness
    echo 1 > /proc/sys/vm/overcommit_memory
    echo 2048 > /proc/sys/vm/min_free_kbytes
    echo 1 > /proc/sys/vm/compact_memory
    echo 1 > /proc/sys/vm/oom_kill_allocating_task
    echo 1 > /proc/sys/vm/panic_on_oom
    echo 3 > /proc/sys/vm/dirty_writeback_centisecs
    echo 50 > /proc/sys/vm/watermark_scale_factor

    # More RAM optimizations
    ram_optimizations=(
        "/proc/sys/vm/max_map_count=262144"
        "/proc/sys/vm/dirty_expire_centisecs=200"
        "/proc/sys/vm/dirty_writeback_centisecs=500"
        "/proc/sys/vm/vfs_cache_pressure=0"
        "/proc/sys/vm/min_free_kbytes=4"
    )

    # Additional scripts and techniques for freeing up memory
    for _ in $(seq 4); do
        ram_optimizations+=(
            "/proc/sys/vm/drop_caches=3"
            "/proc/sys/vm/compact_memory=1"
            "/proc/sys/vm/drop_caches=3"
        )
    done

    # Further techniques for freeing up memory
    ram_optimizations+=(
        "/proc/sys/vm/drop_caches=2"
        "/proc/sys/vm/drop_caches=3"
    )

    # Adjust these values based on testing and preferences
    ram_optimizations+=(
        "/proc/sys/vm/dirty_ratio=80"
        "/proc/sys/vm/dirty_background_ratio=20"
        "/proc/sys/vm/min_free_kbytes=512"
        "/proc/sys/vm/page-cluster=1"
        "/proc/sys/vm/extfrag_threshold=500"
        "/proc/sys/vm/dirty_expire_centisecs=100"
        "/proc/sys/vm/dirty_writeback_centisecs=300"
    )

    # Additional stability-focused tweaks
    ram_optimizations+=(
        "/proc/sys/kernel/random/read_wakeup_threshold=4"
        "/proc/sys/kernel/random/write_wakeup_threshold=32"
    )

    # New Memory and RAM Optimizations
    ram_optimizations+=(
        "/proc/sys/vm/min_free_kbytes=2048"
        "/proc/sys/vm/dirty_ratio=90"
        "/proc/sys/vm/dirty_background_ratio=70"
        "/proc/sys/vm/watermark_boost_factor=50"
    )

    # Fine-tuning for large RAM devices
    if [ "$total_ram" -ge 6144 ]; then
        ram_optimizations+=(
            "/proc/sys/vm/dirty_ratio=85"
            "/proc/sys/vm/dirty_background_ratio=60"
        )
    fi

    # Additional aggressive memory management techniques
    ram_optimizations+=(
        "/proc/sys/vm/overcommit_memory=2"
        "/proc/sys/vm/min_free_order_shift=15000"
        "/proc/sys/vm/panic_on_oom=1"
    )

    # More aggressive swappiness for performance
    ram_optimizations+=(
        "/proc/sys/vm/swappiness=0"
    )

    # Additional kernel parameters for aggressive memory management
    ram_optimizations+=(
        "/proc/sys/vm/extra_free_kbytes=12288"
        "/proc/sys/vm/oom_kill_allocating_task=1"
    )

    # Further aggressive settings for large RAM devices
    if [ "$total_ram" -ge 8192 ]; then
        ram_optimizations+=(
            "/proc/sys/vm/dirty_ratio=90"
            "/proc/sys/vm/dirty_background_ratio=70"
            "/proc/sys/vm/min_free_kbytes=512"
        )
    fi

    # RAM cleaning techniques
    ram_optimizations+=(
        "sync; echo 3 > /proc/sys/vm/drop_caches"
        "/proc/sys/vm/drop_caches=3"
        "/proc/sys/vm/compact_memory=1"
    )

    # Additional cleaning techniques
    ram_optimizations+=(
        "sync; echo 1 > /proc/sys/vm/drop_caches"
        "sync; echo 2 > /proc/sys/vm/drop_caches"
        "sync; echo 3 > /proc/sys/vm/drop_caches"
        "/proc/sys/vm/compact_memory=1"
    )

    # More aggressive cleaning techniques
    ram_optimizations+=(
        "sync; echo 3 > /proc/sys/vm/drop_caches"
        "/proc/sys/vm/drop_caches=3"
        "/proc/sys/vm/compact_memory=1"
    )

    # Fine-tuning for stability
    ram_optimizations+=(
        "/proc/sys/vm/oom_kill_allocating_task=0"
        "/proc/sys/vm/dirty_background_ratio=70"
        "/proc/sys/vm/vfs_cache_pressure=5"
        "/proc/sys/vm/min_free_order_shift=10000"
    )

    # Additional tools for RAM management
    ram_optimizations+=(
        "echo 3 > /proc/sys/vm/drop_caches"
        "sync; echo 1 > /proc/sys/vm/drop_caches"
        "sync; echo 2 > /proc/sys/vm/drop_caches"
    )

    # Execute RAM optimizations
    for opt in "${ram_optimizations[@]}"; do
        eval "$opt"
    done
}

# Function to reduce background usages
reduce_background_usage() {
    # Additional tweaks to reduce background services and apps
    background_tweaks=(
        "/proc/sys/vm/oom_kill_allocating_task=1"
        "/proc/sys/vm/oom_score_adj=200"
    )

    # Additional scripts and techniques
    for _ in $(seq 3); do
        background_tweaks+=(
            "echo 3 > /proc/sys/vm/drop_caches"
            "echo 1 > /proc/sys/vm/compact_memory"
            "sync; echo 3 > /proc/sys/vm/drop_caches"
        )

        # Reduce more background cache
        background_tweaks+=(
            "echo 2 > /proc/sys/vm/drop_caches"
            "echo 3 > /proc/sys/vm/drop_caches"
        )

        # Additional techniques for reducing background cache
        background_tweaks+=(
            "echo 1 > /proc/sys/vm/drop_caches"
            "echo 2 > /proc/sys/vm/drop_caches"
            "echo 1 > /proc/sys/vm/compact_memory"
            "sync; echo 3 > /proc/sys/vm/drop_caches"
        )

        # Further techniques for background cache reduction
        background_tweaks+=(
            "echo 1 > /proc/sys/vm/drop_caches"
            "echo 2 > /proc/sys/vm/drop_caches"
            "sync; echo 3 > /proc/sys/vm/drop_caches"
        )

        # More techniques for reducing background cache
        background_tweaks+=(
            "echo 1 > /proc/sys/vm/drop_caches"
            "echo 2 > /proc/sys/vm/drop_caches"
            "sync; echo 3 > /proc/sys/vm/drop_caches"
        )
    done

    # Gaming-specific tweaks
    background_tweaks+=(
        "echo 2 > /proc/sys/vm/page-cluster"
        "echo 256 > /proc/sys/vm/min_free_kbytes"
        "echo 1 > /proc/sys/vm/extra_free_kbytes"
    )

    # Adjust these values based on testing and preferences
    # Additional tweaks for gaming and frame drops
    background_tweaks+=(
        "echo 70 > /proc/sys/vm/dirty_ratio"
        "echo 50 > /proc/sys/vm/dirty_background_ratio"
    )

    # Enable GMS Doze
    background_tweaks+=(
        "settings put global device_idle_constants idle_constants=1"
        "dumpsys deviceidle enable"
    )

    # AdrenoBoost
    background_tweaks+=(
        "echo 1 > /sys/class/kgsl/kgsl-3d0/adrenoboost"
    )

    # Adreno Idler
    background_tweaks+=(
        "echo 1 > /sys/class/kgsl/kgsl-3d0/idle_timer_enable"
    )

    # SimpleLMK
    echo 256 > /sys/module/lowmemorykiller/parameters/minfree
    echo 4096 > /sys/module/lowmemorykiller/parameters/cost

    # MGLRU Optimization
    echo 1 > /proc/sys/vm/mglru_enabled
    echo 10 > /proc/sys/vm/mglru_max_reclaims
    echo 30 > /proc/sys/vm/mglru_window
    echo 5 > /proc/sys/vm/mglru_min_reclaims
    
    # Sched Optimization
    echo 1 > /proc/sys/kernel/sched_fast_charge
    echo 10 > /proc/sys/kernel/sched_small_task

    # SLMK Adjustment for Better UX
    echo 2048 > /sys/module/lowmemorykiller/parameters/minfree
    echo 4096 > /sys/module/lowmemorykiller/parameters/cost

    # Execute background tweaks
    for tweak in "${background_tweaks[@]}"; do
        eval "$tweak"
    done
}

# Main optimization function
optimize_system() {
    set_device_properties
    optimize_ram_aggressively
    reduce_background_usage
}

# Call the main function
optimize_system
