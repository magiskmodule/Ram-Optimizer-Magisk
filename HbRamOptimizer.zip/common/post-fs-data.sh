#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}
set_device_properties() {
    total_ram=$(free -m | awk '/^Mem:/{print $2}')
    storage_capacity=$(df -h /data | awk 'NR==2{print $2}')
    android_version=$(getprop ro.build.version.release)

    # Adjust configurations based on specifications
    case "$total_ram" in
        512) dirty_ratio_val=5 ;;
        1024) dirty_ratio_val=10 ;;
        2048) dirty_ratio_val=20 ;;
        4096) dirty_ratio_val=40 ;;
        6144) dirty_ratio_val=60 ;;
        8192) dirty_ratio_val=80 ;;
        *) dirty_ratio_val=80 ;;
    esac

    case "$storage_capacity" in
        "32G") dirty_background_bytes_val=2048 ;;
        *) dirty_background_bytes_val=1024 ;;
    esac

    echo "$dirty_ratio_val" > /proc/sys/vm/dirty_ratio
    echo "$dirty_background_bytes_val" > /proc/sys/vm/dirty_background_bytes

    if [ "$(echo "$android_version >= 9.0" | bc -l)" -eq 1 ]; then
        echo 1 > /proc/sys/vm/oom_kill_allocating_task
        echo 3 > /proc/sys/vm/dirty_ratio
    fi
}

# Aggressive tweaks for optimized RAM usage
optimize_ram_aggressively() {
    echo 1 > /proc/sys/vm/drop_caches
    echo 99 > /proc/sys/vm/dirty_ratio
    echo 90 > /proc/sys/vm/dirty_background_ratio
    echo 0 > /proc/sys/vm/swappiness
    echo 1 > /proc/sys/vm/overcommit_memory
    echo 1024 > /proc/sys/vm/min_free_kbytes
    echo 1 > /proc/sys/vm/compact_memory
    echo 1 > /proc/sys/vm/oom_kill_allocating_task
    echo 1 > /proc/sys/vm/panic_on_oom
    echo 3 > /proc/sys/vm/dirty_writeback_centisecs
    echo 5 > /proc/sys/vm/dirty_expire_centisecs
    echo 50 > /proc/sys/vm/watermark_scale_factor

    # Additional tweaks for advanced RAM management
    echo 0 > /proc/sys/vm/oom_kill_allocating_task
    echo 1 > /proc/sys/vm/page-cluster
    echo 10 > /proc/sys/vm/dirty_background_ratio
    echo 40 > /proc/sys/vm/vfs_cache_pressure
    echo 3000 > /proc/sys/vm/min_free_order_shift

    # Additional scripts and techniques
    for _ in $(seq 2); do
        echo 3 > /proc/sys/vm/drop_caches  # Clear pagecache, dentries, and inodes
        echo 1 > /proc/sys/vm/compact_memory  # Compacts memory
        sync; echo 3 > /proc/sys/vm/drop_caches  # Clear caches and free up memory

        # Reduce more background cache
        echo 2 > /proc/sys/vm/drop_caches  # Clear dentries and inodes
        echo 3 > /proc/sys/vm/drop_caches  # Clear pagecache, dentries, and inodes again
        
        # Additional techniques for reducing background cache
        echo 1 > /proc/sys/vm/drop_caches  # Clear pagecache
        echo 2 > /proc/sys/vm/drop_caches  # Clear dentries and inodes again
        echo 1 > /proc/sys/vm/compact_memory  # Compacts memory again
        sync; echo 3 > /proc/sys/vm/drop_caches  # Clear caches and free up memory again

        # Further techniques for background cache reduction
        echo 1 > /proc/sys/vm/drop_caches  # Clear pagecache again
        echo 2 > /proc/sys/vm/drop_caches  # Clear dentries and inodes again
        sync; echo 3 > /proc/sys/vm/drop_caches  # Clear caches and free up memory again

        # More techniques for reducing background cache
        echo 1 > /proc/sys/vm/drop_caches  # Clear pagecache again
        echo 2 > /proc/sys/vm/drop_caches  # Clear dentries and inodes again
        sync; echo 3 > /proc/sys/vm/drop_caches  # Clear caches and free up memory again
    done

    # Gaming-specific tweaks
    echo 512 > /proc/sys/vm/min_free_kbytes
    echo 1 > /proc/sys/vm/page-cluster
    echo 1 > /proc/sys/vm/extra_free_kbytes

    # Adjust these values based on testing and preferences
    # Additional tweaks for gaming and frame drops
    echo 70 > /proc/sys/vm/dirty_ratio
    echo 50 > /proc/sys/vm/dirty_background_ratio

    # Add even more scripts and techniques as needed
}

# Main optimization function for highly aggressive RAM management
optimize_system_highly_aggressively() {
    set_device_properties
    optimize_ram_aggressively
}